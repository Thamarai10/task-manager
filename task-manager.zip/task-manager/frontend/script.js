const API = 'http://localhost:5000/tasks';

async function loadTasks(filter='') {
  const res = await fetch(API + (filter ? '?status=' + filter : ''));
  const data = await res.json();
  const list = document.getElementById('list');
  list.innerHTML = '';

  data.forEach(t => {
    const li = document.createElement('li');
    li.innerHTML = `
      <input value="${t.title}" onchange="editTask(${t.id}, this.value)" />
      [${t.completed ? '✔' : '❌'}]
      <button onclick="toggle(${t.id})">Toggle</button>
      <button onclick="remove(${t.id})">Delete</button>
    `;
    list.appendChild(li);
  });
}

function filterTasks(val){
  loadTasks(val);
}

async function addTask(){
  const val = document.getElementById('taskInput').value;
  await fetch(API,{
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({title:val})
  });
  loadTasks();
}

async function toggle(id){
  await fetch(API+'/'+id,{method:'PATCH'});
  loadTasks();
}

async function remove(id){
  await fetch(API+'/'+id,{method:'DELETE'});
  loadTasks();
}

async function editTask(id,title){
  await fetch(API+'/'+id,{
    method:'PUT',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({title})
  });
}

loadTasks();
