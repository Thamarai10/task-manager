const express = require('express');
const cors = require('cors');
const fs = require('fs');
const app = express();
app.use(cors());
app.use(express.json());

const FILE = 'tasks.json';

let tasks = [];
if (fs.existsSync(FILE)) {
  tasks = JSON.parse(fs.readFileSync(FILE));
}

function save() {
  fs.writeFileSync(FILE, JSON.stringify(tasks, null, 2));
}

// GET with filter
app.get('/tasks', (req, res) => {
  const { status } = req.query;
  if (status === 'completed') return res.json(tasks.filter(t => t.completed));
  if (status === 'pending') return res.json(tasks.filter(t => !t.completed));
  res.json(tasks);
});

// CREATE
app.post('/tasks', (req, res) => {
  const { title } = req.body;
  if (!title) return res.status(400).json({ error: 'Title required' });

  const task = {
    id: Date.now(),
    title,
    completed: false,
    createdAt: new Date()
  };

  tasks.push(task);
  save();
  res.status(201).json(task);
});

// TOGGLE
app.patch('/tasks/:id', (req, res) => {
  const task = tasks.find(t => t.id == req.params.id);
  if (!task) return res.status(404).json({ error: 'Not found' });

  task.completed = !task.completed;
  save();
  res.json(task);
});

// EDIT
app.put('/tasks/:id', (req, res) => {
  const task = tasks.find(t => t.id == req.params.id);
  if (!task) return res.status(404).json({ error: 'Not found' });

  task.title = req.body.title || task.title;
  save();
  res.json(task);
});

// DELETE
app.delete('/tasks/:id', (req, res) => {
  tasks = tasks.filter(t => t.id != req.params.id);
  save();
  res.json({ message: 'Deleted' });
});

app.listen(5000, () => console.log('Server running'));
